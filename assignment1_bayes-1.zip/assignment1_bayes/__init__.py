"""Filtering exercises for robotics package."""
