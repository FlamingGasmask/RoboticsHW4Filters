"""
Filtering Exercises Package
Contains implementations of various filtering algorithms for robot localization.
"""

__version__ = "0.1.0" 